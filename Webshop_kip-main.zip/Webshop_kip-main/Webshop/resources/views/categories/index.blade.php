@extends("master")

@section("content")
index test
@endsection
