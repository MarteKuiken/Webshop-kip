@foreach($products as $product)
{{ $product->name }}
@endforeach